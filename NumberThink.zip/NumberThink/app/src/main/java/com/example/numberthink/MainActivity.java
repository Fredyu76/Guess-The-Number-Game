package com.example.numberthink;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Date currentTime = Calendar.getInstance().getTime();
        ((TextView) findViewById(R.id.editTextTime)).setText("Started @" + currentTime.toString());


    }

    public void buttonClicked(View v){
        // Get the Start Value
        EditText viewStart = (EditText) findViewById(R.id.editTextNumberStart);
        String inputStart = viewStart.getText().toString();

        // Get the End Value
        EditText viewEnd = (EditText) findViewById(R.id.editTextNumberEnd);
        String inputEnd = viewEnd.getText().toString();

        //We get the min and Max value
        int min = GuessModel.toInt(inputStart, 1);
        int max = GuessModel.toInt(inputEnd, 100);
        // Get winning number based on min and max value
        int winning_number = GuessModel.getRandomNumber(min, max);

        // Get the user's Guess
        EditText inputView = (EditText) findViewById(R.id.inputId);
        String input = inputView.getText().toString();

        // Convert guess to int
        int numberGuessed = GuessModel.toInt(input, 50);

        // Compare guess to answer
        String guessOutput = GuessModel.checkNumber(numberGuessed, winning_number);
        int color = GuessModel.getResultColour(numberGuessed, winning_number);

        // Output prompt
        ((TextView) findViewById(R.id.resultId)).setText(guessOutput);
        ((TextView) findViewById(R.id.resultId)).setTextColor(color);
    }

    public void updateClicked(View view) {
        // Update the guessing range based on the inputs
        //Makes it Dynamic

        // Get the Start Value
        EditText viewStart = (EditText) findViewById(R.id.editTextNumberStart);
        String inputStart = viewStart.getText().toString();

        // Get the End Value
        EditText viewEnd = (EditText) findViewById(R.id.editTextNumberEnd);
        String inputEnd = viewEnd.getText().toString();

        // Parse inputs
        int min = GuessModel.toInt(inputStart, 1);
        int max = GuessModel.toInt(inputEnd, 100);

        // Updates the prompt to the values we entered
        String output = "What number am I thinking of? Pick a number between " + min + " to " + max + ".";
        ((TextView) findViewById(R.id.titleTwo)).setText(output);
    }
}