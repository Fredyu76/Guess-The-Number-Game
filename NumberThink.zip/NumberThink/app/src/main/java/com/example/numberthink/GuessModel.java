package com.example.numberthink;

import android.graphics.Color;

import androidx.appcompat.app.AppCompatActivity;



public class GuessModel extends AppCompatActivity {

   public static int getRandomNumber(int min, int max){
       return (int)((Math.random() * (max - min)) + min);
   }

    public static int toInt(String s, int defaultVal){
       //Try to parse the input, if not, use the default value
       try {
           return Integer.parseInt(s);
       }
       catch (Exception e){
           return defaultVal;
       }

    }

   public static String checkNumber(int inputGuess, int answer){
       if (inputGuess < answer) {
           return "Hint : Try a Higher Number!";
       }
       else if (inputGuess > answer) {
           return "Hint : Try a Lower Number!";
       }
       else {
           return "Nice Job! You correctly guessed the number.";
       }
   }

    public static int getResultColour(int inputGuess, int answer){
        if (inputGuess < answer) {
            return Color.WHITE;
        }
        else if (inputGuess > answer) {
            return Color.BLACK;
        }
        else {
            return Color.rgb(118,255,3);
        }
    }




}
